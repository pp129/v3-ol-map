import{j as n,M as r,C as s,a as c}from"./index-DYf1c8VC.js";import{useMDXComponents as i}from"./index-BLUDxe7X.js";import{O as l,D as a,X as h,S as x}from"./OlTile.stories-B7gVn5Zi.js";import"./iframe-8roaxG1A.js";import"./_commonjsHelpers-BosuxZz1.js";import"./index-xINKKZAp.js";import"./index-DrFu-skq.js";import"./components-BlvWkRZs.js";import"./vue.esm-bundler-DiCi7pUq.js";function t(e){const o={blockquote:"blockquote",code:"code",h1:"h1",h2:"h2",p:"p",pre:"pre",...i(),...e.components};return n.jsxs(n.Fragment,{children:[n.jsx(r,{of:l}),`
`,n.jsx(o.h1,{id:"ol-tile",children:"ol-tile"}),`
`,n.jsx(o.p,{children:"瓦片图层"}),`
`,n.jsx(o.pre,{children:n.jsx(o.code,{className:"language-js",children:`import { OlMap, OlTile } from "v-ol-map";
`})}),`
`,n.jsx(s,{of:a}),`
`,n.jsx(o.h2,{id:"xyz",children:"XYZ"}),`
`,n.jsxs(o.blockquote,{children:[`
`,n.jsx(o.p,{children:"自定义 XYZ 规则瓦片图层"}),`
`]}),`
`,n.jsx(s,{of:h}),`
`,n.jsx(o.h2,{id:"switch-tile",children:"Switch Tile"}),`
`,n.jsxs(o.blockquote,{children:[`
`,n.jsx(o.p,{children:"切换瓦片图层"}),`
`]}),`
`,n.jsx(s,{of:x}),`
`,n.jsx(o.h2,{id:"docs",children:"Docs"}),`
`,n.jsx(c,{})]})}function D(e={}){const{wrapper:o}={...i(),...e.components};return o?n.jsx(o,{...e,children:n.jsx(t,{...e})}):t(e)}export{D as default};
