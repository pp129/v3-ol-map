import{b as y,e as x,O as f,_ as b,d as E}from"./components-BlvWkRZs.js";import{d as v,g as _,l as $,m as U,f as a,u as n,o as k,e as t,b as R,F as T,j as V,p as q,k as j}from"./vue.esm-bundler-DiCi7pUq.js";import{i as w}from"./vue-CSDdYaJw.js";const h=v({__name:"index",setup(e){const s={zoom:13,center:[118.11022,24.490474],smoothExtentConstraint:!0,constrainResolution:!0},o=_({type:"FeatureCollection",features:[]});return $(()=>{setTimeout(()=>{o.value.features=[{type:"Feature",geometry:{type:"Point",coordinates:[118.11022,24.490474]},properties:{name:"Point",style:{icon:{src:w,width:24,height:24},text:{text:"在元素上定义样式，>12级才显示文字",font:"13px sans-serif",fill:{color:"#3d73e8"},backgroundFill:{color:"#ffffff"},stroke:{color:"#ffffff",width:1},backgroundStroke:{color:"#000000",width:1},offsetX:0,offsetY:30},styleFunction:function(u,g,Z,i){const r=Z.getView().getZoom(),l=i.getText(),F=u.get("style");let S="";F&&(S=F.text.text);const p=i.getImage();return p&&r&&l&&(p.setScale(r/12),r<=12&&l.setText(""),r>=13&&(l.setText(S),p.setScale(2)),r>=14&&(l.setText(`根据层级显示不同内容,当前层级：${r}级`),p.setScale(1)),i.setText(l),i.setImage(p)),i}}}}]},1e3)}),(u,g)=>(k(),U(n(b),{view:s},{default:a(()=>[t(n(y),{"tile-type":"BAIDU","z-index":0}),t(n(x),{"z-index":1},{default:a(()=>[t(n(f),{"geo-json":o.value},null,8,["geo-json"])]),_:1})]),_:1}))}});h.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/featureStyle/index.vue"};const L=`<script setup lang="ts">
import { FeatureCollection, FeatureStyle, VMap, OlMap, OlTile, OlVector, OlFeature } from "v3-ol-map";
import icon from "@/assets/vue.svg";
import { ref, onMounted } from "vue";
const view: VMap["view"] = {
  zoom: 13,
  center: [118.11022, 24.490474],
  smoothExtentConstraint: true,
  constrainResolution: true,
};
const geometryData = ref<FeatureCollection>({
  type: "FeatureCollection",
  features: [],
});

onMounted(() => {
  setTimeout(() => {
    geometryData.value.features = [
      {
        type: "Feature",
        geometry: {
          type: "Point",
          coordinates: [118.11022, 24.490474],
        },
        properties: {
          name: "Point",
          style: <FeatureStyle>{
            icon: {
              src: icon,
              width: 24,
              height: 24,
            },
            text: {
              text: "在元素上定义样式，>12级才显示文字",
              font: "13px sans-serif",
              fill: {
                color: "#3d73e8",
              },
              backgroundFill: {
                color: "#ffffff",
              },
              stroke: {
                color: "#ffffff",
                width: 1,
              },
              backgroundStroke: {
                color: "#000000",
                width: 1,
              },
              offsetX: 0,
              offsetY: 30,
            },
            styleFunction: function (feature, resolution, map, style) {
              const viewZoom = map.getView().getZoom();
              const textStyle = style.getText();
              const properties = feature.get("style");
              let originText = "";
              if (properties) {
                originText = properties.text.text;
              }
              const image = style.getImage();
              if (image && viewZoom && textStyle) {
                image.setScale(viewZoom / 12);
                if (viewZoom <= 12) {
                  textStyle.setText("");
                }
                if (viewZoom >= 13) {
                  textStyle.setText(originText);
                  image.setScale(2);
                }
                if (viewZoom >= 14) {
                  textStyle.setText(\`根据层级显示不同内容,当前层级：\${viewZoom}级\`);
                  image.setScale(1);
                }
                style.setText(textStyle);
                style.setImage(image);
              }
              return style;
            },
          },
        },
      },
    ];
  }, 1000);
});
<\/script>

<template>
  <ol-map :view="view">
    <ol-tile tile-type="BAIDU" :z-index="0"></ol-tile>
    <ol-vector :z-index="1">
      <ol-feature :geo-json="geometryData"></ol-feature>
    </ol-vector>
  </ol-map>
</template>

<style scoped></style>
`,A=e=>(q("data-v-5a3e0371"),e=e(),j(),e),X=A(()=>V("div",{class:"tips"},"使用 geo-json 参数添加要素",-1)),M=v({__name:"index",setup(e){const s={zoom:13,center:[118.11022,24.490474]},o=_({type:"FeatureCollection",features:[{id:"point1",type:"Feature",geometry:{type:"Point",coordinates:[118.08022,24.480474]},properties:{name:"点要素 1",description:"使用 GeoJSON 格式"}},{id:"point2",type:"Feature",geometry:{type:"Point",coordinates:[118.13022,24.500474]},properties:{name:"点要素 2",description:"GeoJSON Point"}},{id:"line1",type:"Feature",geometry:{type:"LineString",coordinates:[[118.09022,24.470474],[118.10022,24.480474],[118.11022,24.490474],[118.12022,24.500474]]},properties:{name:"线要素",description:"GeoJSON LineString"}},{id:"polygon1",type:"Feature",geometry:{type:"Polygon",coordinates:[[[118.09522,24.510474],[118.10522,24.510474],[118.10522,24.520474],[118.09522,24.520474],[118.09522,24.510474]]]},properties:{name:"多边形要素",description:"GeoJSON Polygon"}}]});return(u,g)=>(k(),R(T,null,[t(n(b),{view:s},{default:a(()=>[t(n(y),{"tile-type":"BAIDU","z-index":0}),t(n(x),{"z-index":1,"layer-style":{"icon-src":n(w),"icon-scale":1,"text-value":["get","name"],"text-fill-color":"white","text-background-fill-color":"#409eff","text-offset-y":25,"text-padding":[4,10,4,10],"stroke-color":"#409eff","stroke-width":3,"fill-color":"rgba(64, 158, 255, 0.2)"}},{default:a(()=>[t(n(f),{"geo-json":o.value},null,8,["geo-json"])]),_:1},8,["layer-style"])]),_:1}),X],64))}}),Y=E(M,[["__scopeId","data-v-5a3e0371"]]);M.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/featureGeoJson/index.vue"};const H=`<script setup lang="ts">
import { ref } from "vue";
import { OlMap, OlTile, OlVector, OlFeature, VMap, GeoJSON } from "v3-ol-map";
import icon from "@/assets/vue.svg";

const view: VMap["view"] = {
  zoom: 13,
  center: [118.11022, 24.490474],
};

// 使用 GeoJSON 格式定义要素
const geoJsonData = ref<GeoJSON>({
  type: "FeatureCollection",
  features: [
    {
      id: "point1",
      type: "Feature",
      geometry: {
        type: "Point",
        coordinates: [118.08022, 24.480474],
      },
      properties: {
        name: "点要素 1",
        description: "使用 GeoJSON 格式",
      },
    },
    {
      id: "point2",
      type: "Feature",
      geometry: {
        type: "Point",
        coordinates: [118.13022, 24.500474],
      },
      properties: {
        name: "点要素 2",
        description: "GeoJSON Point",
      },
    },
    {
      id: "line1",
      type: "Feature",
      geometry: {
        type: "LineString",
        coordinates: [
          [118.09022, 24.470474],
          [118.10022, 24.480474],
          [118.11022, 24.490474],
          [118.12022, 24.500474],
        ],
      },
      properties: {
        name: "线要素",
        description: "GeoJSON LineString",
      },
    },
    {
      id: "polygon1",
      type: "Feature",
      geometry: {
        type: "Polygon",
        coordinates: [
          [
            [118.09522, 24.510474],
            [118.10522, 24.510474],
            [118.10522, 24.520474],
            [118.09522, 24.520474],
            [118.09522, 24.510474],
          ],
        ],
      },
      properties: {
        name: "多边形要素",
        description: "GeoJSON Polygon",
      },
    },
  ],
});
<\/script>

<template>
  <ol-map :view="view">
    <ol-tile tile-type="BAIDU" :z-index="0"></ol-tile>
    <ol-vector
      :z-index="1"
      :layer-style="{
        'icon-src': icon,
        'icon-scale': 1,
        'text-value': ['get', 'name'],
        'text-fill-color': 'white',
        'text-background-fill-color': '#409eff',
        'text-offset-y': 25,
        'text-padding': [4, 10, 4, 10],
        'stroke-color': '#409eff',
        'stroke-width': 3,
        'fill-color': 'rgba(64, 158, 255, 0.2)',
      }"
    >
      <ol-feature :geo-json="geoJsonData" />
    </ol-vector>
  </ol-map>

  <div class="tips">使用 geo-json 参数添加要素</div>
</template>

<style scoped>
.tips {
  position: absolute;
  bottom: 5%;
  left: 50%;
  transform: translate(-50%, 0);
  z-index: 1;
  background-color: rgba(255, 255, 255, 0.95);
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 12px 20px;
  font-size: 14px;
  color: #333;
  backdrop-filter: blur(10px);
}
</style>
`,K=e=>(q("data-v-7a89db2a"),e=e(),j(),e),Q=K(()=>V("div",{class:"tips"},"使用 geometries 参数添加要素",-1)),B=v({__name:"index",setup(e){const s={zoom:13,center:[118.11022,24.490474]},o=_([{type:"Point",geometry:{coordinates:[118.08022,24.480474]},properties:{name:"点要素 1",description:"使用 geometries 格式"}},{type:"Point",geometry:{coordinates:[118.13022,24.500474]},properties:{name:"点要素 2",description:"geometries Point"}},{type:"Circle",geometry:{center:[118.11022,24.490474],radius:800},properties:{name:"圆形要素",description:"geometries Circle"}},{type:"LineString",geometry:{coordinates:[[118.09022,24.470474],[118.10022,24.480474],[118.11022,24.490474],[118.12022,24.500474]]},properties:{name:"线要素",description:"geometries LineString"}},{type:"Polygon",geometry:{coordinates:[[[118.09522,24.510474],[118.10522,24.510474],[118.10522,24.520474],[118.09522,24.520474],[118.09522,24.510474]]]},properties:{name:"多边形要素",description:"geometries Polygon"}}]);return(u,g)=>(k(),R(T,null,[t(n(b),{view:s},{default:a(()=>[t(n(y),{"tile-type":"BAIDU","z-index":0}),t(n(x),{"z-index":1,"layer-style":{"icon-src":n(w),"icon-scale":1,"text-value":["get","name"],"text-fill-color":"white","text-background-fill-color":"#67c23a","text-offset-y":25,"text-padding":[4,10,4,10],"stroke-color":"#67c23a","stroke-width":3,"fill-color":"rgba(103, 194, 58, 0.2)"}},{default:a(()=>[t(n(f),{geometries:o.value},null,8,["geometries"])]),_:1},8,["layer-style"])]),_:1}),Q],64))}}),W=E(B,[["__scopeId","data-v-7a89db2a"]]);B.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/featureGeometries/index.vue"};const ee=`<script setup lang="ts">
import { ref } from "vue";
import { OlMap, OlTile, OlVector, OlFeature, VMap, FeatureGeometry } from "v3-ol-map";
import icon from "@/assets/vue.svg";

const view: VMap["view"] = {
  zoom: 13,
  center: [118.11022, 24.490474],
};

// 使用 geometries 格式定义要素
const geometriesData = ref<FeatureGeometry[]>([
  {
    type: "Point",
    geometry: {
      coordinates: [118.08022, 24.480474],
    },
    properties: {
      name: "点要素 1",
      description: "使用 geometries 格式",
    },
  },
  {
    type: "Point",
    geometry: {
      coordinates: [118.13022, 24.500474],
    },
    properties: {
      name: "点要素 2",
      description: "geometries Point",
    },
  },
  {
    type: "Circle",
    geometry: {
      center: [118.11022, 24.490474],
      radius: 800,
    },
    properties: {
      name: "圆形要素",
      description: "geometries Circle",
    },
  },
  {
    type: "LineString",
    geometry: {
      coordinates: [
        [118.09022, 24.470474],
        [118.10022, 24.480474],
        [118.11022, 24.490474],
        [118.12022, 24.500474],
      ],
    },
    properties: {
      name: "线要素",
      description: "geometries LineString",
    },
  },
  {
    type: "Polygon",
    geometry: {
      coordinates: [
        [
          [118.09522, 24.510474],
          [118.10522, 24.510474],
          [118.10522, 24.520474],
          [118.09522, 24.520474],
          [118.09522, 24.510474],
        ],
      ],
    },
    properties: {
      name: "多边形要素",
      description: "geometries Polygon",
    },
  },
]);
<\/script>

<template>
  <ol-map :view="view">
    <ol-tile tile-type="BAIDU" :z-index="0"></ol-tile>
    <ol-vector
      :z-index="1"
      :layer-style="{
        'icon-src': icon,
        'icon-scale': 1,
        'text-value': ['get', 'name'],
        'text-fill-color': 'white',
        'text-background-fill-color': '#67c23a',
        'text-offset-y': 25,
        'text-padding': [4, 10, 4, 10],
        'stroke-color': '#67c23a',
        'stroke-width': 3,
        'fill-color': 'rgba(103, 194, 58, 0.2)',
      }"
    >
      <ol-feature :geometries="geometriesData" />
    </ol-vector>
  </ol-map>

  <div class="tips">使用 geometries 参数添加要素</div>
</template>

<style scoped>
.tips {
  position: absolute;
  bottom: 5%;
  left: 50%;
  transform: translate(-50%, 0);
  z-index: 1;
  background-color: rgba(255, 255, 255, 0.95);
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 12px 20px;
  font-size: 14px;
  color: #333;
  backdrop-filter: blur(10px);
}
</style>
`,ne={title:"OlMap/Feature",component:f,tags:["!dev"],render:e=>({components:{ExampleFeature:h},template:"<example-feature></example-feature>"})},c={parameters:{docs:{source:{code:L}}},render:e=>({components:{ExampleFeature:h},template:"<example-feature></example-feature>"})},d={parameters:{docs:{source:{code:H}}},render:e=>({components:{ExampleFeatureGeoJson:Y},template:"<example-feature-geo-json></example-feature-geo-json>"})},m={parameters:{docs:{source:{code:ee}}},render:e=>({components:{ExampleFeatureGeometries:W},template:"<example-feature-geometries></example-feature-geometries>"})};var O,G,P;c.parameters={...c.parameters,docs:{...(O=c.parameters)==null?void 0:O.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: ExampleFeatureRaw
      }
    }
  },
  render: args => ({
    components: {
      ExampleFeature
    },
    template: "<example-feature></example-feature>"
  })
}`,...(P=(G=c.parameters)==null?void 0:G.docs)==null?void 0:P.source}}};var N,z,D;d.parameters={...d.parameters,docs:{...(N=d.parameters)==null?void 0:N.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: ExampleFeatureGeoJsonRaw
      }
    }
  },
  render: args => ({
    components: {
      ExampleFeatureGeoJson
    },
    template: "<example-feature-geo-json></example-feature-geo-json>"
  })
}`,...(D=(z=d.parameters)==null?void 0:z.docs)==null?void 0:D.source}}};var I,J,C;m.parameters={...m.parameters,docs:{...(I=m.parameters)==null?void 0:I.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: ExampleFeatureGeometriesRaw
      }
    }
  },
  render: args => ({
    components: {
      ExampleFeatureGeometries
    },
    template: "<example-feature-geometries></example-feature-geometries>"
  })
}`,...(C=(J=m.parameters)==null?void 0:J.docs)==null?void 0:C.source}}};const te=["Default","GeoJson","Geometries"],se=Object.freeze(Object.defineProperty({__proto__:null,Default:c,GeoJson:d,Geometries:m,__namedExportsOrder:te,default:ne},Symbol.toStringTag,{value:"Module"}));export{c as D,d as G,se as O,m as a};
