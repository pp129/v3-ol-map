import{i as r}from"./pako.esm-BkaqWuDM.js";import{B as a}from"./basedecoder-B2c5_Eok.js";class s extends a{decodeBlock(e){return r(new Uint8Array(e)).buffer}}export{s as default};
