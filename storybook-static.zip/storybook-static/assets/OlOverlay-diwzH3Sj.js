import{j as o,M as s,C as a,a as i}from"./index-DYf1c8VC.js";import{useMDXComponents as t}from"./index-BLUDxe7X.js";import{O as m,D as l}from"./OlOverlay.stories-DKTaXBrZ.js";import"./iframe-8roaxG1A.js";import"./_commonjsHelpers-BosuxZz1.js";import"./index-xINKKZAp.js";import"./index-DrFu-skq.js";import"./components-BlvWkRZs.js";import"./vue.esm-bundler-DiCi7pUq.js";import"./vue-CSDdYaJw.js";function r(e){const n={code:"code",h1:"h1",h2:"h2",p:"p",pre:"pre",...t(),...e.components};return o.jsxs(o.Fragment,{children:[o.jsx(s,{of:m}),`
`,o.jsx(n.h1,{id:"ol-overlay",children:"ol-overlay"}),`
`,o.jsx(n.p,{children:"覆盖物组件，用于在地图上显示弹窗、标签等覆盖物"}),`
`,o.jsx(n.pre,{children:o.jsx(n.code,{className:"language-js",children:`import { OlMap, OlOverlay } from "v3-ol-map";
`})}),`
`,o.jsx(a,{of:l}),`
`,o.jsx(n.h2,{id:"docs",children:"Docs"}),`
`,o.jsx(i,{})]})}function C(e={}){const{wrapper:n}={...t(),...e.components};return n?o.jsx(n,{...e,children:o.jsx(r,{...e})}):r(e)}export{C as default};
