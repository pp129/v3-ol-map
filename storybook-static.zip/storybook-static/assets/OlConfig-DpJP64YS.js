import{j as n,M as t,C as i,a as p}from"./index-DYf1c8VC.js";import{useMDXComponents as s}from"./index-BLUDxe7X.js";import{O as a,D as c}from"./OlConfig.stories-CJNLnr5w.js";import"./iframe-8roaxG1A.js";import"./_commonjsHelpers-BosuxZz1.js";import"./index-xINKKZAp.js";import"./index-DrFu-skq.js";import"./components-BlvWkRZs.js";import"./vue.esm-bundler-DiCi7pUq.js";function r(e){const o={blockquote:"blockquote",code:"code",h1:"h1",h2:"h2",h3:"h3",li:"li",ol:"ol",p:"p",pre:"pre",strong:"strong",...s(),...e.components};return n.jsxs(n.Fragment,{children:[n.jsx(t,{of:a}),`
`,n.jsx(o.h1,{id:"ol-config",children:"ol-config"}),`
`,n.jsx(o.p,{children:"配置组件，用于为子组件提供配置上下文（天地图 ak、百度地图 ak、高德地图配置等）"}),`
`,n.jsx(o.h2,{id:"全局配置",children:"全局配置"}),`
`,n.jsxs(o.blockquote,{children:[`
`,n.jsxs(o.p,{children:["在",n.jsx(o.code,{children:"main.ts"}),"中进行全局配置"]}),`
`]}),`
`,n.jsx(o.pre,{children:n.jsx(o.code,{className:"language-js",children:`import { createApp } from "vue";
import "@/style.css";
import App from "@/App.vue";
import router from "@/router";
import olMap from "v3-ol-map";

const app = createApp(App);
app.use(router);
// app.use(olMap); // 不配置TDTak加载不了在线天地图
app.use(olMap, {
  tdt: {
    ak: "88e2f1d5ab64a7477a7361edd6b5f68a", // 天地图ak
  },
  baidu: {
    ak: "5ieMMexWmzB9jivTq6oCRX9j",
  },
  // 配置默认map参数
  map: {
    view: {
      zoom: 10,
      center: [118.125827, 24.637526],
    },
  },
  // 配置默认tile参数
  tile: {
    tileType: "XYZ",
    source: {
      url: import.meta.env.VITE_MAP_URL,
      projection: "EPSG:4490",
    },
  },
});
app.mount("#app");
`})}),`
`,n.jsx(o.h3,{id:"组件形式示例",children:"组件形式示例"}),`
`,n.jsxs(o.p,{children:["左侧地图使用 ",n.jsx(o.code,{children:"OlConfig"})," 提供的天地图 ak，右侧地图使用全局配置的 ak："]}),`
`,n.jsx(i,{of:c}),`
`,n.jsx(o.h3,{id:"配置优先级",children:"配置优先级"}),`
`,n.jsxs(o.ol,{children:[`
`,n.jsxs(o.li,{children:[n.jsx(o.strong,{children:"高优先级"}),"：",n.jsx(o.code,{children:"OlConfig"})," 组件的 props"]}),`
`,n.jsxs(o.li,{children:[n.jsx(o.strong,{children:"低优先级"}),"：全局安装时的配置"]}),`
`]}),`
`,n.jsx(o.h2,{id:"docs",children:"Docs"}),`
`,n.jsx(p,{})]})}function M(e={}){const{wrapper:o}={...s(),...e.components};return o?n.jsx(o,{...e,children:n.jsx(r,{...e})}):r(e)}export{M as default};
