import{_ as o,b as i,c as d,d as u}from"./components-BlvWkRZs.js";import{d as g,b as y,e,f as t,u as n,o as _}from"./vue.esm-bundler-DiCi7pUq.js";const b={class:"container"},p=g({__name:"index",setup(s){const f={tdt:{ak:"316cf152e80bd8a121b23746a5803c8b"}};return(v,w)=>(_(),y("div",b,[e(n(d),{tdt:f.tdt},{default:t(()=>[e(n(o),{target:"map1",class:"map",width:"50%"},{default:t(()=>[e(n(i),{"tile-type":"TDT"})]),_:1})]),_:1},8,["tdt"]),e(n(o),{target:"map2",class:"map",width:"50%"},{default:t(()=>[e(n(i))]),_:1})]))}}),m=u(p,[["__scopeId","data-v-229c75aa"]]);p.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/config/index.vue"};const x=`<script setup lang="ts">
import { OlMap, OlTile, OlConfig } from "v3-ol-map";
const config = {
  tdt: {
    ak: "316cf152e80bd8a121b23746a5803c8b",
  },
};
<\/script>

<template>
  <div class="container">
    <!-- 组件形式注入，优先级高于全局设置 -->
    <ol-config :tdt="config.tdt">
      <ol-map target="map1" class="map" width="50%">
        <ol-tile tile-type="TDT"></ol-tile>
      </ol-map>
    </ol-config>
    <!-- 在main中设置的全局变量-->
    <ol-map target="map2" class="map" width="50%">
      <ol-tile></ol-tile>
    </ol-map>
  </div>
</template>

<style scoped>
.container {
  display: flex;
  justify-content: space-between;
  height: 100vh;
}
</style>
`,h={title:"OlMap/Config",component:d,tags:["!dev"],render:s=>({components:{ExampleConfig:m},template:"<example-config></example-config>"})},a={parameters:{docs:{source:{code:x}}},render:s=>({components:{ExampleConfig:m},template:"<example-config></example-config>"})};var r,l,c;a.parameters={...a.parameters,docs:{...(r=a.parameters)==null?void 0:r.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: ExampleConfigRaw
      }
    }
  },
  render: args => ({
    components: {
      ExampleConfig
    },
    template: "<example-config></example-config>"
  })
}`,...(c=(l=a.parameters)==null?void 0:l.docs)==null?void 0:c.source}}};const k=["Default"],E=Object.freeze(Object.defineProperty({__proto__:null,Default:a,__namedExportsOrder:k,default:h},Symbol.toStringTag,{value:"Module"}));export{a as D,E as O};
