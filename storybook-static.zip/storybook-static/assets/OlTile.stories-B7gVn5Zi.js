import{b as c,_ as m,d as O}from"./components-BlvWkRZs.js";import{d as A,g as p,m as E,f as M,u as n,o as d,q as Y,e as R,j as v,z as Z,b as L,F as D,x as P,t as q,B as N}from"./vue.esm-bundler-DiCi7pUq.js";const B=["value"],X=A({__name:"index",setup(t){const a={zoom:11,center:[118.12582777425764,24.637526109241485]};let e=p("AMAP");const u=[{value:"AMAP",label:"高德地图"},{value:"AMAP_SATELLITE",label:"高德地图-卫星图"},{value:"BAIDU",label:"百度地图"},{value:"BAIDU_SATELLITE",label:"百度地图-卫星图"},{value:"TDT",label:"天地图"},{value:"TDT_SATELLITE",label:"天地图-卫星图"},{value:"TDT_TERRAIN",label:"天地图-地形图"},{value:"XYZ",label:"自定义路径的栅格图层"}],y={url:"http://172.16.34.120:6080/arcgis/rest/services/xiamen/MapServer/tile/{z}/{y}/{x}",projection:"EPSG:4326"};let i=p(void 0);const I=()=>{e.value==="XYZ"?i.value={...y}:i.value=void 0};return(F,f)=>(d(),E(n(m),{class:"map-container",view:a},{default:M(()=>[Y(v("select",{"onUpdate:modelValue":f[0]||(f[0]=s=>Z(e)?e.value=s:e=s),class:"tile-type-selections",onChange:I},[(d(),L(D,null,P(u,s=>v("option",{key:s.value,value:s.value},q(s.label),9,B)),64))],544),[[N,n(e)]]),R(n(c),{"tile-type":n(e),source:n(i)},null,8,["tile-type","source"])]),_:1}))}}),V=O(X,[["__scopeId","data-v-5c0dce21"]]);X.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/tile/index.vue"};const j=`<script setup lang="ts">
import { Ref, ref } from "vue";
import { type SourceOptions, type TileType, type VMap, OlMap, OlTile } from "@/packages";
const view: VMap["view"] = {
  zoom: 11,
  center: [118.12582777425764, 24.637526109241485],
};
let tileType = ref<TileType>("AMAP");
type TileTypeList = {
  value: TileType;
  label: string;
};
const tileTypeList: TileTypeList[] = [
  { value: "AMAP", label: "高德地图" },
  { value: "AMAP_SATELLITE", label: "高德地图-卫星图" },
  { value: "BAIDU", label: "百度地图" },
  { value: "BAIDU_SATELLITE", label: "百度地图-卫星图" },
  { value: "TDT", label: "天地图" },
  { value: "TDT_SATELLITE", label: "天地图-卫星图" },
  { value: "TDT_TERRAIN", label: "天地图-地形图" },
  { value: "XYZ", label: "自定义路径的栅格图层" },
];
const xyz: SourceOptions = {
  url: "http://172.16.34.120:6080/arcgis/rest/services/xiamen/MapServer/tile/{z}/{y}/{x}",
  projection: "EPSG:4326",
};
let source = ref<Ref<SourceOptions> | undefined>(undefined);
const handleSelect = () => {
  if (tileType.value === "XYZ") {
    source.value = { ...xyz };
  } else {
    source.value = undefined;
  }
};
<\/script>

<template>
  <ol-map class="map-container" :view="view">
    <select v-model="tileType" class="tile-type-selections" @change="handleSelect">
      <option v-for="item in tileTypeList" :key="item.value" :value="item.value">
        {{ item.label }}
      </option>
    </select>
    <ol-tile :tile-type="tileType" :source="source"></ol-tile>
  </ol-map>
</template>

<style scoped>
.map-container {
  position: relative;
}
.tile-type-selections {
  position: absolute;
  top: 3%;
  left: 50%;
  transform: translateX(-50%);
  z-index: 999;
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 0.5em;
}
</style>
`,z=A({__name:"index",setup(t){const a={zoom:11,center:[118.12582777425764,24.637526109241485],projection:"EPSG:4326"},e=p({url:"https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",projection:"EPSG:3857",crossOrigin:"anonymous"}),u=p(e);return(y,i)=>(d(),E(n(m),{view:a},{default:M(()=>[R(n(c),{"tile-type":"XYZ",source:u.value,"z-index":0},null,8,["source"])]),_:1}))}});z.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/tileXYZ/index.vue"};const G=`<script lang="ts" setup>
import { OlMap, OlTile, type SourceXYZ, type VMap } from "v3-ol-map";
import { ref, type Ref } from "vue";

const view: VMap["view"] = {
  zoom: 11,
  center: [118.12582777425764, 24.637526109241485],
  projection: "EPSG:4326",
};
const xyz = ref({
  url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
  projection: "EPSG:3857",
  crossOrigin: "anonymous",
});
const source = ref<Ref<SourceXYZ>>(xyz);
<\/script>

<template>
  <ol-map :view="view">
    <ol-tile tile-type="XYZ" :source="source" :z-index="0"></ol-tile>
  </ol-map>
</template>

<style scoped></style>
`,C={title:"OlMap/Tile",component:c,tags:["!dev"],render:t=>({components:{OlMap:m,OlTile:c},setup(){const a=t.source,e=t.tileType;return{source:a,tileType:e}},template:`
        <ol-map>
          <ol-tile :tile-type="tileType" :source="source"></ol-tile>
        </ol-map>
    `})},r={args:{tileType:"AMAP"}},l={parameters:{docs:{source:{code:G}}},render:t=>({components:{TileXYZ:z},setup(){return{}},template:`
        <tile-XYZ></tile-XYZ>
    `})},o={parameters:{docs:{source:{code:j}}},render:t=>({components:{SwitchTile:V},setup(){return{}},template:`
        <switch-tile></switch-tile>
    `})};var g,T,b;r.parameters={...r.parameters,docs:{...(g=r.parameters)==null?void 0:g.docs,source:{originalSource:`{
  args: {
    tileType: "AMAP"
  }
}`,...(b=(T=r.parameters)==null?void 0:T.docs)==null?void 0:b.source}}};var _,h,S;l.parameters={...l.parameters,docs:{...(_=l.parameters)==null?void 0:_.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: TileXYZRaw
      }
    }
  },
  render: args => ({
    components: {
      TileXYZ
    },
    setup() {
      return {};
    },
    template: \`
        <tile-XYZ></tile-XYZ>
    \`
  })
}`,...(S=(h=l.parameters)==null?void 0:h.docs)==null?void 0:S.source}}};var x,w,k;o.parameters={...o.parameters,docs:{...(x=o.parameters)==null?void 0:x.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: SwitchTileRaw
      }
    }
  },
  render: args => ({
    components: {
      SwitchTile
    },
    setup() {
      return {};
    },
    template: \`
        <switch-tile></switch-tile>
    \`
  })
}`,...(k=(w=o.parameters)==null?void 0:w.docs)==null?void 0:k.source}}};const U=["Default","XYZ","Switch"],H=Object.freeze(Object.defineProperty({__proto__:null,Default:r,Switch:o,XYZ:l,__namedExportsOrder:U,default:C},Symbol.toStringTag,{value:"Module"}));export{r as D,H as O,o as S,l as X};
