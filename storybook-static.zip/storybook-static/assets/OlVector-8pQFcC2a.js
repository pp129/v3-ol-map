import{j as o,M as s,C as i,a}from"./index-DYf1c8VC.js";import{useMDXComponents as r}from"./index-BLUDxe7X.js";import{O as c,D as m}from"./OlVector.stories-DAsojy5G.js";import"./iframe-8roaxG1A.js";import"./_commonjsHelpers-BosuxZz1.js";import"./index-xINKKZAp.js";import"./index-DrFu-skq.js";import"./components-BlvWkRZs.js";import"./vue.esm-bundler-DiCi7pUq.js";import"./vue-CSDdYaJw.js";function e(t){const n={code:"code",h1:"h1",h2:"h2",p:"p",pre:"pre",...r(),...t.components};return o.jsxs(o.Fragment,{children:[o.jsx(s,{of:c}),`
`,o.jsx(n.h1,{id:"ol-tile",children:"ol-tile"}),`
`,o.jsx(n.p,{children:"瓦片图层"}),`
`,o.jsx(n.pre,{children:o.jsx(n.code,{className:"language-js",children:`import { OlMap, OlVector } from "v-ol-map";
`})}),`
`,o.jsx(i,{of:m}),`
`,o.jsx(n.h2,{id:"docs",children:"Docs"}),`
`,o.jsx(a,{})]})}function D(t={}){const{wrapper:n}={...r(),...t.components};return n?o.jsx(n,{...t,children:o.jsx(e,{...t})}):e(t)}export{D as default};
