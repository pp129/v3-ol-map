import{B as o}from"./basedecoder-B2c5_Eok.js";class d extends o{decodeBlock(e){return e}}export{d as default};
