const t={parameters:{controls:{matchers:{color:/(background|color)$/i,date:/Date$/i}}},decorators:[()=>({template:'<div style="width: 100%;height: 60vh;"><story/></div>'})]};export{t as default};
