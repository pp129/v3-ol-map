import{_ as r}from"./components-BlvWkRZs.js";import"./vue.esm-bundler-DiCi7pUq.js";import"./_commonjsHelpers-BosuxZz1.js";import"./iframe-8roaxG1A.js";const d={title:"OlMap/Map",component:r,tags:["autodocs","!dev"],render:s=>({components:{OlMap:r},setup(){return{args:s}},template:'<ol-map v-bind="args" />'})},e={args:{}};var a,t,o;e.parameters={...e.parameters,docs:{...(a=e.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {}
}`,...(o=(t=e.parameters)==null?void 0:t.docs)==null?void 0:o.source}}};const i=["Default"];export{e as Default,i as __namedExportsOrder,d as default};
