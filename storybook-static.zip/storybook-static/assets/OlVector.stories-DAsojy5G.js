import{b as H,e as u,O as Y,f as X,_ as j,g as L,d as M}from"./components-BlvWkRZs.js";import{d as I,g as l,r as J,y as E,l as W,b as K,o as Z,e as r,f as i,u as o,n as Q,j as m,z as _,t as $,q as ee,A as ne,T as te,F as oe}from"./vue.esm-bundler-DiCi7pUq.js";import{i as ae}from"./vue-CSDdYaJw.js";const re="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAAA0CAYAAAAqunDVAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9kEGAgqEZIAg5UAAAs7SURBVGjevZpbjF1ndcd//31mxmOPx/bEcWKcQBOapKkTBTBY3KFKC6nacBHhgbZSURHwQOAFzhY8cBEXCcE5AokHUFUEqHmIkCo1KomQgkqlJqFABCgxIcVuSNI4xOPY4xmP537O/vOw197nm+PbmRtbGp05l/3tb31rff/1X//1ic2+2gbIAAENoIEN0gh2gdQBjF2+ln8Feda7v6kNTWH9d7cK6omU70eBUaShMCRDysKAeJoIA8EWUoHdRepiryAt0NTKRtdV6/JEU6VRIKQxYGcYAbaRynFt18+Ij2oD4cK/gxXgLLBUL1r/Am6qUT2DMqSd2DvCG5Ux6ZjVhDthVBGfqQ7N0kAnXnTy/TLSHE3NrzUsteZwaxXbkXYDWYRSFV6VR4w9B8wjdS46kbbB3oa0A3t7b0aJceVYBdJpmuoMapjW5B3YA2wHivr+0jsd7AWkeewhpB3AbuwJpJ3ASEyUCLkF7LPAGWAWaR4Q9k5gWwBNtUDVYs1gz5Fnl/WaBjRoGGkiJuz63nIVp2lqkbYPANcDY9gjMTGvAojV/1eT7WAvIU1jHyXPZml7HNgVIJPuyyXsKfLMG/NUqxgG9vWBgIFFYBq4CrgtjOnWAHAhxKshwqwarzfxIWASeDy8vhdpuA9MloHTlzJs6LL7SNqWAEHpHTiJtAv79WFwAXRqqLYbETozwBzSbO01exhpHHssvNEFijB6BftKpLdiP4/0ZKDqFckCDSM1gM76jJKgqXMJ2nXJs0navh771vhVN0JR4aVZ4Cns4wmI7Ad2R0gejZxk7CHg5cANATyKkBPwUuyrgEfCe/vieVM01dlo+BGbcwf2InArcF0fWBRhxDFgHPsWpFuBlwH767Asr0bkouPAs0hHgCexh4GbkK6OsZ0k6CNIJ7EhzxYvl7e0Rji/DumVtevtDDiH9BD2PqR/Cq+MJPunl2TTPZXCt7SI/TjSPRGSrw3jHVGwAjxMnp0bBNa1jsT75xEuID0NHMO+A+kdsZlTD2YRcivYy/G87UkuKhKEHAbOYt+D9CRwGJiIUP0lTZ3YGkbRC8WbsWeBBeBupOsiV1VgMoI0A/wceAz7RWA+Vn8MuBY4BBwOAzt1TpIy7P8hz75DqzgInCDPptZCldbO/VJmAa1YYSdAcQb4N+AX2Dcj3Y59YyDaCaSngIew/xt4EXg38MbgkBVtGgKep6nP/fFYehWKbd8JvDP2yALSvcBzwN3YdwE3rULS1TkKpIeB78Qi3IH99joHSt+iqf9dK5ndWOnR89xdwJuQPge8AfvfkbYl9Ob8e3rcrgKN55Fej70f6YPYbfLs2HoM2rhRPfCYQLob+GISQoOOXSHcOaT3Yf+IPFveSLGYRaVa1UfrvT6A/cUkF2nNC1sS3/uRXrU5RWLJ74zUpSmf54lLh9+7gPtWFX3rvUr07GDfRJ49s6ZoWUWTyrpmd6BYl1axFFRnhKYWL1q+lwMeAP5l0/ZnuSjDSJ8H3j/QorqOtJHgqSui7Sx4VSN+NBcP+AtgLtDsd6EluPZkuRifQGpvunhT8cWSZ642rBJ2SmJ7LU09Rdv7gmaBtCjabkT5oEh+LwbleU0w8iGk+4H3ROH3NPAk0nHsJ5AObrJBVRjfS1N/H14YA/40GP9MlDq7or57IArLHZEmikrKypJNvox0VfL+LE2tYN8GvAbpvUh/ib0bOLjpXurVYn8XBn0B+CrSR4G/xl6K8r+LtIJ9FXanlhYgy4DhpADrhqtHksdU4XhNAr9PA3/LVl1V/moVtyA1on4qkG5BOlfzy9KQsWD9dRrJEsmKpJAbCzQrmULbY9gN7IoOnUX6MyS21LByr09FNaB4/ngSRQ6t0elcsosM6MTYLrAfqYhYXwJOYU/0LQhbFIqTfcg6dEH0S+aSXRaFyoHPJQMPA+NRR7HFl4PVuw/2L+bZMGq1cqoLFHHbyLPJJFQzYFsoO1tskgvgGqCo66+mTq9Sfav9t8pT5Y2rPVfCpsJTO+K7MzGIgYPY98aCeEs8VE7yCNK28E6GNE3bo8niK8SdBn1GdJEUkxWtYgiYSdw5Hq9HYxAj3QgciyJRW+AhIf02VKrRWOgG8FjMp1r8DOlUbIkKSMjCtZ2YnCORnUkk5RFaxQT20VoKhhuBfdjf3kLk+wj2ochJDpX3Z8DeJJcZexZpuNbxpeUs4LCbDLkdez7ESsV3NwBP1J+VEvP7ge8CS7WkvHmeOkJTP0b6m6SqPkGePQdcnRg+RZ4V4anq3uWMpozdrS0vY7iDgsyWe+4A0umAcqKfdAMwjf1Aotpuxl7qIjVpFW8DroxxM+BHtIpdwN4k0R6nVQzXObQ0dLGC9KUELo29DXuyhvQyRK8F7kMaTZDmH4C7gJ9seG/1WM3XsX+DdFdo7CDNYT+ayHOK10mk8Yg2BdPoVEbNJ8BgYAdwLJSdyoMvI88ew/51osldF3rEX8Xn6QTXhnTlPvky0qeAD9d9KrsB/CwmvQe7iDnNAPPJniP0waKsfMs6aTHJUUN1bEMjDN5Jq7gV+Gek2bqFI70a+Efgduz/SJiAB/BO2g76LPA17I/VPLPkfb+jqXuxb6vTj9TAfgoYr9lPOdYieUaW1CrTSQIWcAXwDNLZeF8gvTwU1O8ndGUZOBQaxfuw7wwg0UWTc69XBfAr4AD2d5E+Gcy/6vvOAN+kVRxE2lXDOEySZyeiV+Y6JeXZXI9BtGv+NBEKarU5T0et9YokTIz9IPBW4L1JKsgCQO5B+gX2u4EPIe3H3rOqrwUnsY+FbngE+w7gPUhLCTAsYH8rmnKvTRTeDtKD2DtrrbBco7OVLK2+8nwEe2/y8Kptcwj7mrrDUYbqfyIdxv5QGFOpswJOAc8C/xpJc88qUcaeQroFeB1wfTDvIlmcWeyvxvvDtdfL18eRTgB7k0hYieIW8iwxqidQXoE9WjMMWKSpKdq+vY9cNrD/K3pNH49WD8l9C8CXaOrUBcSa0Qi1A30KlLGfBb4R4X8oWEW1GC+QZ4/S9kv6+OkZ8mzxfJberIntVBzgqGjHKG3vwn4oEm21VwrgzdjbkT6NfR9wDhiNjXsyjg6cf+XZIvbvE4K8Hfsk9veArwA3Ih2KxO945iR59iit4soEXIS9lBp0fulRKUb2mb7NvDM42I+RFmqDy1C5GftNwMNIecjIc8D/09TyJajQb8PbLwAt8uwzIfLciXRtX/dkGunntL0vTs4QYd4Fpvp1S11CzxtD2hPN6opkzkTj7TDS1dFMqx7cCMZxLDp/o/0r2Df+eFStp6JreD3SRNL2rMjzszR1hFaxN0qetIA9RZ6t9CtOl+vOj2PvSg52GHspypA/AV5ZS2eVdl4dBGnqgQFaQm/BHoujP6TiSRj0SDTL99V95F6z7xR5tnQhPTK7jPI5G/skTaajSPuA57AfRJoKbypJvNOrUsX5e4q6RkvPWJTP6QDPkWc/iDDenzTGq/1cGtQjDus4HFKCwRVUp77KUHQg3ExocC+N5tso9k/Js+MDjD0B3B57Ywk4CrwQOWlPvX96DTlHI3vpUh2RbCAqk2cL2KeCd6ULsQP7QPz/BE3dDzyCdPyiXkpD0J7G/j/sn9DUD4FnIp1cHTJdet6pJLCXMWhw/bvXsmkAu5C2rzos1YPYJWAOe3HgvlKraIRkMFrXRf2Ht8pW7DnyzIPo64M9uToKl2fd2AdTwQVV8y7HASoYGVhlKr25E3scezhZKNVdeXsSaXZQgzbW8y0nNRakcriO+b7sPoBh1eGs9BTaEtJ83XVZY0dx7b3HsoldeXAu9tqL0f7pJAx70Gs5PLQc2sjJAIPyEMg6WqR/AP8TaUdhTpMSAAAAAElFTkSuQmCC",se="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAABBCAYAAABlwHJGAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9kEGAgqLMpoz4QAAA70SURBVHjaxZzdj5z3Vcc/55nZN9u7tuO3JE5T20mTNE5KBHKbNgj6GlQKUqu2ggYV9YYb2nLDJVIFEhf8BYgLCi0VpUgUKUJCVKQIElKiElQKTuIkdmK7SezEIX7b15md53Bxvr99zjwex7vrXXska3ZnZ57n9zu/c77ne77njI1NeNRA1fo9Pwy6eosBHY/flw2W9ZaBw8AA1wv5eq4PbuTDNnHzZmAOlcG4wwQwZjCWN1R+tCvX4kDfoQ8sWfxcW/zbcKPYRhvAoXLoGkw6TBiM532vcuFOGDGv0w16DkvAIjCokrO113HTPMKhA0wSJz8hT3Bt/Ir9lxe8tZhR7/fkMR6eNnDoWRhk0WSQ6/EOu15PqOMiW4EtyO192N1di8d1P920nzY9kCHL38e1efT5let5y2AKnfkK5q/HGLaOk8cbI4wbbCfAztqnqR/KuotLLznU1ZUYmnGjEohOEOE1oeu7NWGTcaUGlh0uVPG8ssZNMUSOwxq2G2wpp529PZ38osOshRuX8NnusIPwoskUPuUCC8CcwwWDSwa1jDMJbPV49uxxaR+1w1wFl9eKG7ZaL7BhMLyFAMHivtYKh3ngklB+m8N+g70exquSu2NXx42CBReAN4Az8qgOMGMwlUHVhg9i0cKQvlqD2Bq9YNziNLsFxPJpFA/QJnYBdxPPeJP2VhvGZZNmYfza4C3ghMN5GXxamcnaOAL0UKisxhi22pCgZYTWaSwhd3S4FbjLYIdIkXuzwGwEs1bi8BZUZDyg4SUd4G3gFYM3RcamC1BbE5qmdV0QWduY0AC2ATPe8mILAyw47AYOGeyVe9aWQM3jQCotbtHjxBas2b8DXWHAOM1zLZzI4Fg85CzwivBkq8caszEA3rEIleszRNmxmOK0w1ZbeYnzHta+F7jTw2u8lfe7BFi+TZzgRQvDLSrz7NFmK4NzdXxuksCAncKW3UBHmJHhpRIenTR4WZ/ZkbLKZYfZaqNCI4OYR7qcknuOGXzAYzOFKxQ3rggmeMLgtMFiDbcD9xi8x+F2GWsyhcyCDPmyDHfM4JxHdjogj+toX4WfmHjIWeB/9PstylaztkpQsnUSqEqn9ohyvSUXL6dxHHhJ7v5hg18Cdol+d4T+tDCiGHOZwJcaeN3h34Afq1i7z+Fg8rx8zzmHH4mKe7WGFLpmQpUMcr9FVvDEHUzg9Kzo76MOn5YHeYtsefKinJ4zFuRTvww8bvCkBxD/PLCtGCRh1jGD4/VmEqoRofIg4bJl0SeAlwwOOTxmcEA1gbdOPDPOQcpA3RatJhEu8wjFFx2+a3DW4TBwR7rWcYNj6ynA1l1rJBB9gIj3Fzzy/CeBLyhlDWhqjEqrnRWIXQbmiNjuWYTabQ5TAuUZZYI6nToWobZs8D2Hp2XsQ8CrFby03ip0I8rwigDQCYNfBz7oAjMaA1Rih88BR0WIam16RmD7huj1vAcn2G1h5MMOe2TUYpAS/k8C/wR0qsg46y7Fr8sQrdj+ZeAxuX8tL+gSOf4Jhx8TFPtRhw8BdxAb3KaNvqHC7KxHlnna4QmB5ocdPiGvWfZG5VoE/szg6E0XZhJejDt81uDjMkbX4adEPM8AX3d41OCgB3gOVUwj9IlZC8x5HPhTGfXLBGfpqfz+B4MfWmOcm/vw4Z9/s4a/rOHzdRjjtxxO17FYr8U6XW5+rX916BYnHD6l6/12Dd90+NVR97/pj3rYGPc6WA1/oA3VdbOx1RqhHvHz7+hed19NGN6Q06w39lr/uMaNX8szynW+c0M9wa/PCN/YSCOM8IyvbrgxVD9UNWytYcwb6rsuT3H4ylpxYI2e4R5F269t6AF7bHTK4Y4a9nnUA9v0+pZ6RGqur3Jxh0M1vFJvggFahnCHf5f2cc2Dqkfvu/JQ27fWMFZpExN6f4emH4EFhX7Y4X6HfbV6FFXLAIlLfA24c7OjVvc94vBFrkKi8ubFvrp1o5ZNqwDcITK4pXD7LsN5vKcP7NXzTqLie64OKe5e4DmLAqsY4X0OH7dQnzftkaS4cYNPO/ydwZk2q9TmZwxu9WCpU/Kkfy3dt1THjHXFACeKECtjLHmQIJIi5A5zBncBX3R4rA6R5T88mONHgXs2sT05isf9ogq/M1UjEz7gcKfBUx7E6+5U8velnPdbFxvr2nBHqdTSyy43Sqxv0aMO2K82XsdCOXrE4D8d7kNWt00meUn/nAYO1CHR/Yk3yvYiwUqPqvjr0OgoOwmxJ4e1VaSmrB7L2kzHhm+8ZKEg3VYsrMXM6v0HrSmvN/1hTe/ksGqQvsW/ZULRut3CgwetUB0n3jMk6FZJAyyn71WEwc6Wp/TVQJnMjuJx8zEPzfJm0Pv7JPEtJvXatabahzdsahJd0XetrpZj7cqssyy0nSgnohb9O/Kq6ibYAZ14R5olyVOnCaG5btVCPspl17J4t0irncQbasXb+IgQu5HGQCLPqDbtqMELb6P5WmW9OYVCeaEjdXlBAHWzql832GEtAMzN6FH48q4ekciRtbBjTApSz4e7UaUJc8P1AGt00NphX1bDPUL2YkqdKz3VUdeqrMUQRT1NfYV803E1a+YZVqO3CjRf9CY+b4gX6Eb/paZTt0VgBmoUd1vhfTmr59kj+qkx4zSDXi2JgQliGOS0iEm56RShPp/kBqbPshmDF9TQycXiZYOfab2d1oKW1GvpWtOKWGnR1ymmnEg953w4y0zK8q+m6Tf02iGPBsw7fgOkgoT8r3kY4v2WygT1Yt/0EIbHkqeWNmU3NYbMYnClqS0y6agiN/e8YXGVLH/aG2AsnnKYoNpHbYO00NWQKYcnDF7V/TuJ28xazFNsl0cUtrssjxjz4YzSqxIHt9bmAM5Z02mqCUo9BxxPVLoGDkig/XsPYnMjqs8LBo979FL3egPwA4NT8vKZ1mDaO9YAfPawfiWr9GzYpcfUxj+n5zKqswO4xeAp0usq0D5h8E2DF2wTQyNls39x+IHBw2oplr8vAk8Z7NXheALWMwL8sdxSBJZK1ij02dJwxhTwGk2PorjSQYMXLbyiktsNgF8gOk5f2kxJUVZ40+GrFve8v3TDdM+3DE6pa5aHTAZVGGIqVw4WHtRPU0Espda/EypVrZZ+VZikw34PNP6+CFX5WOVhhNdVpttGGiSd6oLBl1RRftaHB9jc4G/rmPG6LU3pmjptKJN4op4rnfPSaF304XGeLiFlnUguWbzlQYtewzNC6xKb+xy+rsbL5wVOdj38IoGaWYhCnwGeAb7iMUhSW9NafNZipOielusb8Hwd2Nct+FYG34wQbVcGQEs7rRhHRcucB3foJKKyX7rE9+SmpSzvSZz5feCfgS84vN6evFurAfSBE8BnPAjUlwWSff2tY/CGw7fraCXuR+W3POc1rW26hV/LBR+rqtn4smYacst+UtT6pFJsYWR9hwe12O8obxcGt+Rwt8PX1PL7FPA3NJOxtkpjrCA98OfEUMrrwO9JDFqg6YHOOXzboqn8QCkDtI+ewTGawdXMiueVXVZOEgP+MDY64Q1rQ9P05wmD7E51RYcodJ4Xk3ufdESXu+4y+IDBmzLWU0p5B0XCRup5yUKnZYA/NvgWcMTgNwg5rmS5rgdm/DUxnfNBeXHxpjERrnMWuFGlGc4auFypTLdWIxfF3VR63R0uaXFHlJvLELhZIPGzwCcNPqfUW+LWJIyccnha0tkeC6H3IYOHXDMUenQU/z8lYv2C3vew1PEOzcI7BK5932I84IjDvrS2rg7hWaXXbQxP280Cl9I4VJM29OKk+EKVDLQs+ryXEEvHW/Y7WcHRGj5mIbF3/Moh8p6Y6vNVNHHHvHHVzBgXHQ4CHxV1n9bJ5piqNJn3XQvDHSGqzzyjveTwE3nhrjQWbTRz272y7+6IunxRKvZkitUuMFMFIO0C3ptmsA24q473P0ngye8iMpOuUWYn99FIf/2rAOV7gI9IJ7XkmeXkzgB/YcFzPuRBnkjGrwnqfU7hXCXQcY029kbqEa0vn1xMaSkXXdMG/0tkAvcmvw8ItP4IMejxDYNnPFWpxV3lqtfKGMdE1syHddMl4rp/5PC2wyPArZaG1GWMN6qYu9wh9YyULfo2Ymi9O6pDVEUb/6LBzhZh2aYw+Yly8u5krGUCkD6mCZZvGfzQ4Vfk4jvk0i9cqz1n8H+ax9otAnVBnvYD4c17xSjHaTCmhPkZh/+WxD/V4hMFIK+Q6uzduid1uHcZ4Vt5v0Bs3uB+ouFT3DFPv50RGTsvgHzI4/T+imvMRmuG6nNE6+BFgedbwqgDFoOrvVSAVRJxTxFzWltUeRYxpqTtS1W0H67YuK2iU75dxqiHhSwuKX8fIrpJW8oGdaPSKjhPoPdZueU156I17jwjfdTUo9hD4FNVMk1qV845vFzBSY+JvGmGcaVS/+Xi1YZQ7Vo9NS1qpybg6pSHXTn8onSKwwqNgQ1/eaUUPgOLqdgLq2SWkx5F1RRxb0sqWllDV8B5zGMdO8u3fVI9URGNnos2IiS4Gka0LaR4uqjfp0hz0Pp9jPj7j6Ro31cycUHwJKQM1lBjVNINtpCm/WmG0fviJackFe5J7DZ7whzxTSCv3+Xku6vptBoMBJ4mi+dUNWbhEXMqzU8D7ycGQWua736+JdRf7aOnecyZzHm0plfFJJeUybYkIdqTweaFC/W1ehdrms7XanaKD1jrKwOl63S+ik1MeADbHSrbX7KYul/1AE4dHvZzKq76Bj9zOF7BsnjLTFKv81cjXNnmXcNhzYZo9/mVTaZKReoJmVPDeBYBYx11x4LB/GqmY+vh+YbbJLGdE0BMqp033upmleUN9AW3Wdik6fyWMSYtcvV4qy5Z6TJJ7V7Q6fTXcy/tdEJzDZNFT2DY+AUXehYFYG+tQxrrUpvTiVXAFg2Pd9MUvjPM7ReIePe1GqOk78QJhib9U0d+TiKL1+voZ3bXY4iUi2vl5yVrvpfZSYsulLe3HkFXYeWtOC+02/QFl1nJjMtrCYUNMUTLGBj0a301Wa2AbUqrRdjtr9VVU8Yq/0tAlcKuXzCI9L8HXM+80roNQdbzm1MY1GGMeRliq/60vNY4TJvrK9O4hkHmyhB61er/X09X6f8BG5mwUI4lZGMAAAAASUVORK5CYII=",le={class:"content"},ie={class:"tips"},R=I({__name:"index",setup(f){const F={zoom:12,center:[118.11022,24.490474]},p=[{filter:["==",["get","name"],"Point2"],style:{"text-value":["get","name"],"text-fill-color":"white","text-background-fill-color":"orange","text-offset-y":28,"text-padding":[2,8,2,8],"icon-src":re}},{filter:["==",["get","name"],"Point3"],style:{"text-value":["get","name"],"text-fill-color":"white","text-background-fill-color":"red","text-offset-y":28,"text-padding":[2,8,2,8],"icon-src":se}},{filter:["==",["get","name"],"Circle"],style:{"text-value":["get","radius_size"],"text-fill-color":"white","text-background-fill-color":"black","text-offset-y":0,"text-font":"bold 16px serif","text-padding":[2,8,2,8],"stroke-color":"red","stroke-width":4,"fill-color":"rgba(0,255,255,0.5)"}},{filter:["==",["get","name"],"Polygon"],style:{"text-value":"多边形","text-fill-color":"white","text-background-fill-color":"green","text-offset-y":0,"text-font":"bold 16px serif","text-padding":[2,8,2,8],"stroke-color":"pink","stroke-width":4,"fill-color":"rgba(255,255,0,0.5)"}},{else:!0,style:{"text-value":["get","name"],"text-fill-color":"white","text-background-fill-color":"red","text-offset-y":28,"text-padding":[2,8,2,8],"icon-src":ae,"stroke-color":"black","stroke-width":8,"fill-color":"rgba(255,255,0,0.5)"}}];let A=l(),y=l();const n=()=>{const e=118.06+Math.random()/7,t=24.43+Math.random()/7;return[e,t]},v=()=>Math.floor(Math.random()*3)+1,x=()=>{const t=[{id:"1",name:"Point"+v(),longitude:n()[0],latitude:n()[1]},{id:"2",name:"Point"+v(),longitude:n()[0],latitude:n()[1]}].map(a=>({id:a.id,type:"Feature",geometry:{type:"Point",coordinates:[a.longitude,a.latitude]},properties:a}));A.value={type:"FeatureCollection",features:t},y.value=[{type:"Circle",geometry:{center:n(),radius:500},properties:{name:"Circle",radius_size:"500"}},{type:"Polygon",geometry:{coordinates:[[n(),n(),n(),n(),n()]]},properties:{name:"Polygon"}},{type:"LineString",geometry:{coordinates:[n(),n(),n(),n()]},properties:{name:"LineString"}}]};let k=J({name:""}),s=l();const b=(...e)=>{const[t,a]=e;if(a){const d=a.getGeometry();if(d){const U=d.getType();if(k.name=a.get("name"),U==="Point")s.value=d.getCoordinates()||t.coordinate;else{const{topCenter:z}=L(d);s.value=z}}}};let g=l(!1),w=l(!1);const G=()=>{x(),g.value=!1},h=E(),C=()=>{var e;w.value||(g.value=!0),w.value=!0,(e=h.value)==null||e.getLayer()},O=(...e)=>{const[t]=e},N=(...e)=>{const[t]=e},V=(...e)=>{const[t]=e},T=(...e)=>{const[t]=e},q=(...e)=>{const[t]=e};return W(()=>{x()}),(e,t)=>(Z(),K(oe,null,[r(o(j),{view:F,onDblclick:G},{default:i(()=>[r(o(H),{"tile-type":"BAIDU","z-index":0}),r(o(u),{ref_key:"vectorRef",ref:h,"layer-style":p,"z-index":1,onSingleclick:b,onSourceready:C,onFeaturesloadend:N,onFeaturesloadstart:V,onChangefeature:T,onChange:q},{default:i(()=>[r(o(Y),{"geo-json":o(A)},null,8,["geo-json"])]),_:1},512),r(o(u),{"layer-style":p,"z-index":1,translate:!0,onSingleclick:b,onSourceready:C,onTranslateend:O},{default:i(()=>[r(o(Y),{geometries:o(y)},null,8,["geometries"])]),_:1}),r(o(X),{position:o(s),class:Q(["overlay"]),positioning:"bottom-center",offset:[0,-20]},{default:i(()=>[m("i",{class:"close",onClick:t[0]||(t[0]=a=>_(s)?s.value=void 0:s=void 0)},"×"),m("div",le,$(o(k).name),1)]),_:1},8,["position"])]),_:1}),r(te,{name:"nested"},{default:i(()=>[ee(m("div",ie,"双击地图随机改变矢量图层要素~",512),[[ne,o(g)]])]),_:1})],64))}}),S=M(R,[["__scopeId","data-v-809d5992"]]);R.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/vector/index.vue"};const ce=`<script setup lang="ts">
import { onMounted, reactive, ref, shallowRef } from "vue";
import {
  FeatureGeometry,
  GeoJSON,
  GeoJSONFeature,
  VectorLayerOptions,
  VMap,
  SimpleGeometry,
  utils,
  Position,
  OlVectorInstance,
  OlMap,
  OlTile,
  OlVector,
  OlFeature,
  OlOverlay,
} from "v3-ol-map";
import icon from "@/assets/vue.svg";
import cluster2 from "@/assets/images/cluster2.png";
import cluster3 from "@/assets/images/cluster3.png";

const view: VMap["view"] = {
  zoom: 12,
  center: [118.11022, 24.490474],
};
const layerStyle: VectorLayerOptions["layerStyle"] = [
  {
    // 当geojson.features[index].properties.name的值为Point2时显示图标cluster2
    filter: ["==", ["get", "name"], "Point2"],
    style: {
      "text-value": ["get", "name"],
      "text-fill-color": "white",
      "text-background-fill-color": "orange",
      "text-offset-y": 28,
      "text-padding": [2, 8, 2, 8],
      "icon-src": cluster2,
    },
  },
  {
    filter: ["==", ["get", "name"], "Point3"],
    style: {
      "text-value": ["get", "name"],
      "text-fill-color": "white",
      "text-background-fill-color": "red",
      "text-offset-y": 28,
      "text-padding": [2, 8, 2, 8],
      "icon-src": cluster3,
    },
  },
  {
    filter: ["==", ["get", "name"], "Circle"],
    style: {
      "text-value": ["get", "radius_size"],
      "text-fill-color": "white",
      "text-background-fill-color": "black",
      "text-offset-y": 0,
      "text-font": "bold 16px serif",
      "text-padding": [2, 8, 2, 8],
      "stroke-color": "red", //圆的边框颜色
      "stroke-width": 4, //圆的边框宽度
      "fill-color": "rgba(0,255,255,0.5)", //圆的填充颜色
    },
  },
  {
    filter: ["==", ["get", "name"], "Polygon"],
    style: {
      "text-value": "多边形",
      "text-fill-color": "white",
      "text-background-fill-color": "green",
      "text-offset-y": 0,
      "text-font": "bold 16px serif",
      "text-padding": [2, 8, 2, 8],
      "stroke-color": "pink", //圆的边框颜色
      "stroke-width": 4, //圆的边框宽度
      "fill-color": "rgba(255,255,0,0.5)", //圆的填充颜色
    },
  },
  {
    else: true,
    style: {
      "text-value": ["get", "name"],
      "text-fill-color": "white",
      "text-background-fill-color": "red",
      "text-offset-y": 28,
      "text-padding": [2, 8, 2, 8],
      "icon-src": icon,
      "stroke-color": "black", //圆的边框颜色
      "stroke-width": 8, //圆的边框宽度
      "fill-color": "rgba(255,255,0,0.5)", //圆的填充颜色
    },
  },
];
let geojson = ref<GeoJSON>();
let geometryData = ref<FeatureGeometry[]>();
// 生成厦门岛范围的随机经纬度
const mockCoordinates = () => {
  const x = 118.06 + Math.random() / 7;
  const y = 24.43 + Math.random() / 7;
  return [x, y];
};
// 生成[1-3]范围的随机数
const mockRandom = () => {
  return Math.floor(Math.random() * 3) + 1;
};
const getVectorData = () => {
  const mockData = [
    {
      id: "1",
      name: "Point" + mockRandom(),
      longitude: mockCoordinates()[0],
      latitude: mockCoordinates()[1],
    },
    {
      id: "2",
      name: "Point" + mockRandom(),
      longitude: mockCoordinates()[0],
      latitude: mockCoordinates()[1],
    },
  ];
  const features: GeoJSONFeature[] = mockData.map(item => {
    return {
      id: item.id,
      type: "Feature",
      geometry: {
        type: "Point",
        coordinates: [item.longitude, item.latitude],
      },
      properties: item,
    };
  });
  geojson.value = {
    type: "FeatureCollection",
    features,
  };
  geometryData.value = [
    {
      type: "Circle",
      geometry: {
        center: mockCoordinates(),
        radius: 500,
      },
      properties: {
        name: "Circle",
        radius_size: "500",
      },
    },
    {
      type: "Polygon",
      geometry: {
        coordinates: [[mockCoordinates(), mockCoordinates(), mockCoordinates(), mockCoordinates(), mockCoordinates()]],
      },
      properties: {
        name: "Polygon",
      },
    },
    {
      type: "LineString",
      geometry: {
        coordinates: [mockCoordinates(), mockCoordinates(), mockCoordinates(), mockCoordinates()],
      },
      properties: {
        name: "LineString",
      },
    },
  ];
};
let info = reactive({
  name: "",
});
let position = ref<Position>();
const onClickLayer = (...args: any[]) => {
  const [evt, feature] = args;
  if (feature) {
    const geom = feature.getGeometry() as SimpleGeometry;
    if (geom) {
      const type = geom.getType();
      info.name = feature.get("name");
      if (type === "Point") {
        position.value = geom.getCoordinates() || evt.coordinate;
      } else {
        const { topCenter } = utils.calculateCenter(geom);
        position.value = topCenter;
      }
    }
  }
};
let showTips = ref(false);
let mapInit = ref(false);

const handleDblclick = () => {
  getVectorData();
  showTips.value = false;
};
const vectorRef = shallowRef<OlVectorInstance>();
const onSourceReady = () => {
  if (!mapInit.value) showTips.value = true;
  mapInit.value = true;
  const layer = vectorRef.value?.getLayer();
  console.log(layer?.getSource());
};
const translateend = (...args: any[]) => {
  const [evt] = args;
  console.log(evt);
};
const onFeaturesLoadEnd = (...args: any[]) => {
  const [e] = args;
  console.log("load end", e);
};
const onFeaturesLoadStart = (...args: any[]) => {
  const [e] = args;
  console.log("load start", e);
};
const changefeature = (...args: any[]) => {
  const [e] = args;
  console.log("feature change", e);
};
const onchange = (...args: any[]) => {
  const [e] = args;
  console.log("change", e.target.getFeatures());
};
onMounted(() => {
  getVectorData();
});
<\/script>

<template>
  <ol-map :view="view" @dblclick="handleDblclick">
    <ol-tile tile-type="BAIDU" :z-index="0"></ol-tile>
    <ol-vector
      ref="vectorRef"
      :layer-style="layerStyle"
      :z-index="1"
      @singleclick="onClickLayer"
      @sourceready="onSourceReady"
      @featuresloadend="onFeaturesLoadEnd"
      @featuresloadstart="onFeaturesLoadStart"
      @changefeature="changefeature"
      @change="onchange"
    >
      <ol-feature :geo-json="geojson" />
    </ol-vector>
    <ol-vector
      :layer-style="layerStyle"
      :z-index="1"
      :translate="true"
      @singleclick="onClickLayer"
      @sourceready="onSourceReady"
      @translateend="translateend"
    >
      <ol-feature :geometries="geometryData" />
    </ol-vector>
    <ol-overlay :position="position" :class="['overlay']" positioning="bottom-center" :offset="[0, -20]">
      <i class="close" @click="position = undefined">&times;</i>
      <div class="content">
        {{ info.name }}
      </div>
    </ol-overlay>
  </ol-map>
  <Transition name="nested">
    <div v-show="showTips" class="tips">双击地图随机改变矢量图层要素~</div>
  </Transition>
</template>

<style scoped>
.overlay {
  background-color: rgba(255, 255, 255, 0.8);
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  position: relative;
}
.overlay .content {
  z-index: 1;
}
.overlay .close {
  position: absolute;
  right: 2px;
  top: 2px;
  cursor: pointer;
  z-index: 2;
}

.tips {
  position: absolute;
  bottom: 5%;
  left: 50%;
  transform: translate(-50%, 0);
  z-index: 1;
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 5px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  padding: 12px;
  font-size: 16px;
  color: #000;
}
.nested-enter-active,
.nested-leave-active {
  transition: all 0.3s ease-in-out;
}
/* delay leave of parent element */
.nested-leave-active {
  transition-delay: 0.25s;
}

.nested-enter-from,
.nested-leave-to {
  transform: translateY(100%) translateX(-50%);
  opacity: 0;
}
</style>
`,de={title:"OlMap/Vector",component:u,tags:["!dev"],render:f=>({components:{ExampleVector:S},template:"<example-vector></example-vector>"})},c={parameters:{docs:{source:{code:ce}}},render:f=>({components:{ExampleVector:S},template:"<example-vector></example-vector>"})};var P,D,B;c.parameters={...c.parameters,docs:{...(P=c.parameters)==null?void 0:P.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: ExampleVectorRaw
      }
    }
  },
  render: args => ({
    components: {
      ExampleVector
    },
    template: "<example-vector></example-vector>"
  })
}`,...(B=(D=c.parameters)==null?void 0:D.docs)==null?void 0:B.source}}};const ge=["Default"],pe=Object.freeze(Object.defineProperty({__proto__:null,Default:c,__namedExportsOrder:ge,default:de},Symbol.toStringTag,{value:"Module"}));export{c as D,pe as O};
