import{j as n,M as i,C as c,a as d}from"./index-DYf1c8VC.js";import{useMDXComponents as l}from"./index-BLUDxe7X.js";import{O as t,D as o}from"./OlCluster.stories-CBzzEN8m.js";import"./iframe-8roaxG1A.js";import"./_commonjsHelpers-BosuxZz1.js";import"./index-xINKKZAp.js";import"./index-DrFu-skq.js";import"./components-BlvWkRZs.js";import"./vue.esm-bundler-DiCi7pUq.js";import"./vue-CSDdYaJw.js";function e(r){const s={code:"code",h1:"h1",h2:"h2",li:"li",p:"p",pre:"pre",strong:"strong",ul:"ul",...l(),...r.components};return n.jsxs(n.Fragment,{children:[n.jsx(i,{of:t}),`
`,n.jsx(s.h1,{id:"ol-cluster",children:"ol-cluster"}),`
`,n.jsx(s.p,{children:"聚合图层组件，用于在地图上展示大量点位数据时进行聚合显示，提升性能和视觉效果"}),`
`,n.jsx(s.pre,{children:n.jsx(s.code,{className:"language-js",children:`import { OlMap, OlCluster, OlFeature } from "v3-ol-map";
`})}),`
`,n.jsx(s.h2,{id:"功能特性",children:"功能特性"}),`
`,n.jsxs(s.ul,{children:[`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"点位聚合"}),"：自动将相邻的点位聚合成一个点，显示数量"]}),`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"动态聚合"}),"：根据地图缩放级别动态调整聚合半径"]}),`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"SuperCluster 支持"}),"：高性能的点位聚合算法"]}),`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"自定义样式"}),"：支持单个点和聚合点的样式配置"]}),`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"交互能力"}),"：支持点击事件，可获取聚合点下的子集"]}),`
`]}),`
`,n.jsx(s.h2,{id:"使用场景",children:"使用场景"}),`
`,n.jsx(s.p,{children:"适用于大量点位数据的展示，如："}),`
`,n.jsxs(s.ul,{children:[`
`,n.jsx(s.li,{children:"监控摄像头分布"}),`
`,n.jsx(s.li,{children:"商家门店位置"}),`
`,n.jsx(s.li,{children:"设备设施分布"}),`
`,n.jsx(s.li,{children:"POI 点位展示"}),`
`]}),`
`,n.jsx(s.h2,{id:"示例",children:"示例"}),`
`,n.jsx(c,{of:o}),`
`,n.jsx(s.h2,{id:"主要属性",children:"主要属性"}),`
`,n.jsxs(s.ul,{children:[`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"super-cluster"}),": SuperCluster 配置，包含 radius（聚合半径）等参数"]}),`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"layer-style"}),": 单个点位的样式配置"]}),`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"cluster-style"}),": 聚合点的样式配置"]}),`
`]}),`
`,n.jsx(s.h2,{id:"事件",children:"事件"}),`
`,n.jsxs(s.ul,{children:[`
`,n.jsxs(s.li,{children:[n.jsx(s.strong,{children:"singleclick"}),": 点击聚合点或单个点时触发"]}),`
`,n.jsxs(s.li,{children:["通过 ",n.jsx(s.code,{children:"ref"})," 获取实例后可调用 ",n.jsx(s.code,{children:"getLeaves(id)"})," 方法获取聚合点下的子集"]}),`
`]}),`
`,n.jsx(s.h2,{id:"docs",children:"Docs"}),`
`,n.jsx(d,{})]})}function M(r={}){const{wrapper:s}={...l(),...r.components};return s?n.jsx(s,{...r,children:n.jsx(e,{...r})}):e(r)}export{M as default};
