import{b as R,h as k,O as L,f as j,_ as q,d as V}from"./components-BlvWkRZs.js";import{d as z,g as i,r as A,l as B,m as p,f,u as l,o as r,q as J,e as _,s as O,j as P,v as $,n as U,b as c,F as G,x as T,t as W}from"./vue.esm-bundler-DiCi7pUq.js";import{i as H}from"./vue-CSDdYaJw.js";const K=""+new URL("cluster4-DPepexmu.png",import.meta.url).href,Q={key:0},X=["onClick"],Y={key:1},b=z({__name:"index",setup(m){const F={zoom:8,center:[118.12582777425764,24.637526109241485]},S={icon:{src:H,scale:.6}},I={icon:{src:K},text:{fill:{color:"#fff"}}},u=i({radius:50}),d=i(),n=A({cluster:!1,list:[],info:{device_code:"",NAME:""},position:void 0});let y=i();const N=(s,e)=>{var t;if(e)if(n.cluster=e.get("cluster"),n.cluster){n.list=[];const a=e.get("cluster_id");if(e.get("point_count")<=10){const g=(t=y.value)==null?void 0:t.getLeaves(a,1/0);g&&(n.list=g.map(E=>E.properties))}n.position=e.get("coordinates")||s.coordinate}else n.info=e.get("properties"),n.position=e.get("coordinates")||s.coordinate},M=s=>{var t;const e=(t=d.value)==null?void 0:t.features.find(a=>a.properties.device_code===s);e&&(n.info=e.properties,n.cluster=!1)};let v=i(!1);const D=()=>{let s=[];fetch("http://172.16.34.132:8222/geoserver/test/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=test:camera_30w&outputFormat=application/json&maxFeatures=20000").then(e=>e.json()).then(e=>{s=e.features,d.value={type:"FeatureCollection",features:s},v.value=!0})};return B(()=>{D()}),(s,e)=>(r(),p(l(q),{view:F,onDblclick:e[1]||(e[1]=t=>n.position=void 0)},{default:f(()=>[J(P("input",{"onUpdate:modelValue":e[0]||(e[0]=t=>u.value.radius=t),class:"slider",type:"range",min:"10",max:"200",step:"10"},null,512),[[$,u.value.radius]]),_(l(R),{"tile-type":"BAIDU"}),l(v)?(r(),p(l(k),{key:0,"z-index":2,"class-name":"layer-cluster","layer-style":S,"cluster-style":I,"super-cluster":u.value,onSingleclick:N},{default:f(()=>[_(l(L),{ref_key:"clusterRef",ref:y,"geo-json":d.value},null,8,["geo-json"])]),_:1},8,["super-cluster"])):O("",!0),n.cluster?(r(),p(l(j),{key:1,class:U(["overlay","overlay-cluster"]),position:n.position},{default:f(()=>[n.list.length>0?(r(),c("ul",Q,[(r(!0),c(G,null,T(n.list,t=>(r(),c("li",{key:t.device_code,onClick:a=>M(t.device_code)},W(t.NAME),9,X))),128))])):(r(),c("span",Y,"尝试点击聚合数≤10的点，显示聚合点位列表"))]),_:1},8,["position"])):O("",!0)]),_:1}))}}),w=V(b,[["__scopeId","data-v-49eac322"]]);b.__docgenInfo={exportName:"default",displayName:"index",type:1,props:[{name:"key",global:!0,description:"",tags:[],required:!1,type:"string | number | symbol | undefined",declarations:[],schema:{kind:"enum",type:"string | number | symbol | undefined",schema:["undefined","string","number","symbol"]}},{name:"ref",global:!0,description:"",tags:[],required:!1,type:"VNodeRef | undefined",declarations:[],schema:{kind:"enum",type:"VNodeRef | undefined",schema:["undefined","string","Ref<any>",{kind:"event",type:"(ref: ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}>, {}, {}> | Element | null, refs: Record<...>): void"}]}},{name:"ref_for",global:!0,description:"",tags:[],required:!1,type:"boolean | undefined",declarations:[],schema:{kind:"enum",type:"boolean | undefined",schema:["undefined","false","true"]}},{name:"ref_key",global:!0,description:"",tags:[],required:!1,type:"string | undefined",declarations:[],schema:{kind:"enum",type:"string | undefined",schema:["undefined","string"]}},{name:"class",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"},{name:"style",global:!0,description:"",tags:[],required:!1,type:"unknown",declarations:[],schema:"unknown"}],events:[],slots:[],exposed:[],sourceFiles:"/Users/feipan/Desktop/项目/v3-ol-map/src/examples/cluster/index.vue"};const Z=`<script setup lang="ts">
import { onMounted, reactive, ref } from "vue";
import icon from "@/assets/vue.svg";
import cluster4 from "@/assets/images/cluster4.png";
import {
  ClusterLayerOptions,
  OlFeatureInstance,
  VMap,
  GeoJSONFeature,
  FeatureCollection,
  OlMap,
  OlCluster,
  OlOverlay,
  OlTile,
  OlFeature,
} from "v3-ol-map";

// 地图视图配置
const view: VMap["view"] = {
  zoom: 8,
  center: [118.12582777425764, 24.637526109241485],
};
// 单个要素样式配置
const layerStyle: ClusterLayerOptions["layerStyle"] = {
  icon: {
    src: icon,
    scale: 0.6,
  },
};
// 聚合样式配置
const clusterStyle: ClusterLayerOptions["clusterStyle"] = {
  icon: {
    src: cluster4, //该聚合样式图标
  },
  text: {
    fill: {
      color: "#fff",
    },
  },
};
const clusterOptions = ref({
  radius: 50,
});
const clusterJson = ref<FeatureCollection>();
type clusterPointInfo = {
  device_code: string;
  NAME?: string;
};
interface OverlayClusterOptions {
  cluster?: boolean;
  list: clusterPointInfo[];
  info?: clusterPointInfo;
  position?: number[];
}
const clusterOverlay = <OverlayClusterOptions>reactive({
  cluster: false,
  list: [],
  info: {
    device_code: "",
    NAME: "",
  },
  position: undefined,
});

let clusterRef = ref<OlFeatureInstance>();
// 聚合层点击事件
const onClickClusterLayer = (evt: any, feature: any) => {
  console.log("onClickClusterLayer", evt, feature);
  if (feature) {
    clusterOverlay.cluster = feature.get("cluster");
    if (clusterOverlay.cluster) {
      clusterOverlay.list = [];
      const id = feature.get("cluster_id");
      const count = feature.get("point_count");
      if (count <= 10) {
        const children = clusterRef.value?.getLeaves(id, Infinity);
        if (children) {
          console.log("children", children);
          clusterOverlay.list = children.map((child: any) => {
            return child.properties;
          });
        }
      }
      clusterOverlay.position = feature.get("coordinates") || evt.coordinate;
    } else {
      console.log(feature.get("properties"));
      clusterOverlay.info = feature.get("properties");
      clusterOverlay.position = feature.get("coordinates") || evt.coordinate;
    }
  }
};
const showClusterItem = (code: string) => {
  const feature = clusterJson.value?.features.find((x: any) => x.properties.device_code === code);
  if (feature) {
    clusterOverlay.info = feature.properties as clusterPointInfo;
    clusterOverlay.cluster = false;
  }
};

let loaded = ref(false);

// 获取点位数据
const getClusterData = () => {
  let features: GeoJSONFeature[] = [];
  fetch(
    "http://172.16.34.132:8222/geoserver/test/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=test:camera_30w&outputFormat=application/json&maxFeatures=20000",
  )
    .then(res => res.json())
    .then((data: any) => {
      console.log(data);
      features = data.features;
      clusterJson.value = { type: "FeatureCollection", features };
      loaded.value = true;
    });
};

onMounted(() => {
  getClusterData();
});
<\/script>

<template>
  <ol-map :view="view" @dblclick="clusterOverlay.position = undefined">
    <input v-model="clusterOptions.radius" class="slider" type="range" min="10" max="200" step="10" />
    <ol-tile tile-type="BAIDU"></ol-tile>
    <ol-cluster
      v-if="loaded"
      :z-index="2"
      class-name="layer-cluster"
      :layer-style="layerStyle"
      :cluster-style="clusterStyle"
      :super-cluster="clusterOptions"
      @singleclick="onClickClusterLayer"
    >
      <ol-feature ref="clusterRef" :geo-json="clusterJson" />
    </ol-cluster>
    <ol-overlay
      v-if="clusterOverlay.cluster"
      :class="['overlay', 'overlay-cluster']"
      :position="clusterOverlay.position"
    >
      <ul v-if="clusterOverlay.list.length > 0">
        <li v-for="item in clusterOverlay.list" :key="item.device_code" @click="showClusterItem(item.device_code)">
          {{ item.NAME }}
        </li>
      </ul>
      <span v-else>尝试点击聚合数&le;10的点，显示聚合点位列表</span>
    </ol-overlay>
  </ol-map>
</template>

<style scoped>
.slider {
  position: absolute;
  z-index: 10;
  top: 20px;
  left: 100px;
}
</style>
`,ee={title:"OlMap/Cluster",component:k,tags:["!dev"],render:m=>({components:{ExampleCluster:w},template:"<example-cluster></example-cluster>"})},o={parameters:{docs:{source:{code:Z}}},render:m=>({components:{ExampleCluster:w},template:"<example-cluster></example-cluster>"})};var C,x,h;o.parameters={...o.parameters,docs:{...(C=o.parameters)==null?void 0:C.docs,source:{originalSource:`{
  parameters: {
    docs: {
      source: {
        code: ExampleClusterRaw
      }
    }
  },
  render: args => ({
    components: {
      ExampleCluster
    },
    template: "<example-cluster></example-cluster>"
  })
}`,...(h=(x=o.parameters)==null?void 0:x.docs)==null?void 0:h.source}}};const ne=["Default"],oe=Object.freeze(Object.defineProperty({__proto__:null,Default:o,__namedExportsOrder:ne,default:ee},Symbol.toStringTag,{value:"Module"}));export{o as D,oe as O};
