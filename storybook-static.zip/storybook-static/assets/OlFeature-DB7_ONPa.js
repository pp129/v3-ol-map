import{j as e,M as i,C as r,a}from"./index-DYf1c8VC.js";import{useMDXComponents as t}from"./index-BLUDxe7X.js";import{O as l,G as c,a as m,D as d}from"./OlFeature.stories-DqW0nQWp.js";import"./iframe-8roaxG1A.js";import"./_commonjsHelpers-BosuxZz1.js";import"./index-xINKKZAp.js";import"./index-DrFu-skq.js";import"./components-BlvWkRZs.js";import"./vue.esm-bundler-DiCi7pUq.js";import"./vue-CSDdYaJw.js";function s(o){const n={code:"code",h1:"h1",h2:"h2",h3:"h3",p:"p",pre:"pre",...t(),...o.components};return e.jsxs(e.Fragment,{children:[e.jsx(i,{of:l}),`
`,e.jsx(n.h1,{id:"ol-feature",children:"ol-feature"}),`
`,e.jsx(n.p,{children:"地图要素组件，用于在矢量图层中添加各种几何要素（点、线、面、圆等）"}),`
`,e.jsx(n.pre,{children:e.jsx(n.code,{className:"language-js",children:`import { OlMap, OlFeature } from "v3-ol-map";
`})}),`
`,e.jsx(n.h2,{id:"参数类型",children:"参数类型"}),`
`,e.jsx(n.p,{children:"OlFeature 支持两种参数类型："}),`
`,e.jsx(n.h3,{id:"1-geo-json-参数",children:"1. geo-json 参数"}),`
`,e.jsx(n.p,{children:"使用标准的 GeoJSON 格式定义要素，支持 Point、LineString、Polygon 等类型。"}),`
`,e.jsx(r,{of:c}),`
`,e.jsx(n.h3,{id:"2-geometries-参数",children:"2. geometries 参数"}),`
`,e.jsx(n.p,{children:"使用自定义的 geometries 格式定义要素，支持 Point、LineString、Polygon、Circle 等类型，Circle 类型仅 geometries 支持。"}),`
`,e.jsx(r,{of:m}),`
`,e.jsx(n.h3,{id:"3-样式定义",children:"3. 样式定义"}),`
`,e.jsx(n.p,{children:"通过 feature 的 properties.style 可以为单个要素定义自定义样式。"}),`
`,e.jsx(r,{of:d}),`
`,e.jsx(n.h2,{id:"docs",children:"Docs"}),`
`,e.jsx(a,{})]})}function O(o={}){const{wrapper:n}={...t(),...o.components};return n?e.jsx(n,{...o,children:e.jsx(s,{...o})}):s(o)}export{O as default};
